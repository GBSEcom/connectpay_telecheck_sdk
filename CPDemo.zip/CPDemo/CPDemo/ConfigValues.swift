//
//  ConfigValues.swift
//  CPDemo
//
//  Created by Michael Thornton on 9/23/19.
//  Copyright © 2019 Michael Thornton. All rights reserved.
//

import Foundation

//let createSessionTokenEndPoint = "https://qa.api.firstdata.com/connectpayapi/v1/security/createsessiontoken"
//let apiKey = "P8uAm7Af2xIOZQvfZCsQy3IJ3oqKpm6l"
//let authorizationKey = "eL5I4FCGMD+xSEDDg3Q1uxazUCrKcce4yFZ2YeTqJ0="
//let fdCustomerId = "TCKQA-20190501-4782"
//let callBackEndpoint = "https://qa.api.firstdata.com/connectpayapi/v1/static/v3/tool/internal/cp-sdk.html?apiKey=P8uAm7Af2xIOZQvfZCsQy3IJ3oqKpm6l&secretKey=QTzAYKHFufFND32H"
//
//enum UseCases: String {
//    case manualEnrollment = "2cdb3cad-b30d-46e3-a458-5ba445b4af3e"
//    case microDepositWithAccountInput = "a02ea15a-0e33-438f-b499-9d72c4b749e6"
//    case bankOnly = "fbe2a2a4-0f6e-4c9b-82eb-15c3685daa7c"
//}

let createSessionTokenEndPoint = ""
let apiKey = ""
let authorizationKey = ""
let fdCustomerId = ""
let callBackEndpoint = "https://cat.api.firstdata.com/gateway/v2/connectpay/static/v1/tool/internal/cp-sdk.html?apiKey=gtyPCSAbyteL0GGF3lGPNVMRrUe7NA8L&secretKey=a00aa39akjk5kQ9b"

enum UseCases: String {
    case manualEnrollment = "2cdb3cad-b30d-46e3-a458-5ba445b4af3e"
    case microDepositWithAccountInput = "a02ea15a-0e33-438f-b499-9d72c4b749e6"
    case bankOnly = "fbe2a2a4-0f6e-4c9b-82eb-15c3685daa7c"
}

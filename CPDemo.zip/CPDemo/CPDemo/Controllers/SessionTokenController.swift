//
//  SessionTokenController.swift
//  CPDemo
//
//  Created by Michael Thornton on 9/23/19.
//  Copyright © 2019 Michael Thornton. All rights reserved.
//

import Foundation




class SessionTokenController {
    
    public static let shared = SessionTokenController()
    
    
    public var sessionTokenData: SessionTokenData?
    
    
    func fetchSessionTokenWithCompletionHandler(_ completionHandler : @escaping () -> Void) {
        
        
        //if we have a token that is not expired, we don't need to fetch a new one
        if let token = self.sessionTokenData {
            if !token.isExpired {
                completionHandler()
                return
            }
        }
        
        
        guard let url = URL(string: createSessionTokenEndPoint) else {
            print("error creating url")
            return
        }
        
        
        var request = URLRequest(url: url)
        
        request.httpMethod = "POST"
        
        request.addValue(apiKey, forHTTPHeaderField: "Api-Key")
        request.addValue("application/JSON", forHTTPHeaderField: "Content-Type")
        request.addValue("\(Date().timeIntervalSince1970)", forHTTPHeaderField: "Timestamp")
        request.addValue(authorizationKey, forHTTPHeaderField: "Authorization")
        
        
        let requestBody = "{\"security\":{\"publicKeyRequired\": \"true\"}}"
        request.httpBody = requestBody.data(using: .utf8)
        
        
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: request) { (data, response, error) in
            
            // call failed if we have an error object or no data
            if error != nil || data == nil {
                print("got an error")
                return
            }
            
            if let data = data {
                print("got back : \(String(decoding: data, as: UTF8.self))")
                
                let jsonDecoder = JSONDecoder()
                
                do {
                    self.sessionTokenData = try jsonDecoder.decode(SessionTokenData.self, from: data)
                    completionHandler()
                }
                catch let error {
                    print("error decoding \(error.localizedDescription)")
                }
            }
        }
        
        
        task.resume()
    }
} // end class

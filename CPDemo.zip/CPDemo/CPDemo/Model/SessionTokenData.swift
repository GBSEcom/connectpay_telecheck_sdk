//
//  SessionTokenData.swift
//  CPDemo
//
//  Created by Michael Thornton on 9/23/19.
//  Copyright © 2019 Michael Thornton. All rights reserved.
//

import Foundation


class SessionTokenData : Codable {
    
    var transactionStatus: String
    var transactionStatusCode : Int
    var referenceTransactionID: String
    var transactionStatusDescription: String
    
    var security: SecurityData

    var isExpired : Bool {
        
        guard let expiry = security.expirationDate else {
            return true
        }
        
        return expiry < Date()
        
    }
    
} // end class

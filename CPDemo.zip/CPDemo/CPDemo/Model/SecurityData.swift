//
//  SecurityData.swift
//  CPDemo
//
//  Created by Michael Thornton on 9/23/19.
//  Copyright © 2019 Michael Thornton. All rights reserved.
//

import Foundation


class SecurityData : Codable {
    
    var tokenID: String
    var issuedOn: String
    var expiresInSeconds: String
    var publicKey: String
    var algorithm: String
    var status: String
    
    
    var expirationDate: Date? {
        
        var issuedOnEpoch = self.issuedOn

        // the service gives us a more precise epoch time than is convient in swift
        //just look at the first 10 digits
        if issuedOnEpoch.count > 10 {
            issuedOnEpoch = String(issuedOnEpoch.prefix(10))
        }
        
        guard let issuedOn = Double(issuedOnEpoch), let seconds = Double(self.expiresInSeconds) else {
            return nil
        }
        
        return  Date(timeIntervalSince1970: issuedOn).addingTimeInterval(seconds)

    }

} // end class

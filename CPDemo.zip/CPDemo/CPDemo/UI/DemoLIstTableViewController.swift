//
//  DemoLIstTableViewController.swift
//  CPDemo
//
//  Created by Michael Thornton on 9/24/19.
//  Copyright © 2019 Michael Thornton. All rights reserved.
//

import UIKit
import PaymentSDK


class DemoLIstTableViewController: UITableViewController {

    let featureList = ["Manual Enrollment", "Micro Deposit With Account Input"]

    let sdk = CPSDK(withApiKey: apiKey, andEnvironment: .qa)
    


    override func viewDidLoad() {
        super.viewDidLoad()
    }



    // MARK: - Table view data source


    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return featureList.count
    }

    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = featureList[indexPath.row]
        
        return cell
    }

    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            manualEnrollment()
        case 1:
            accountValidation()

        default:
            return
        }
    }

    

    private func manualEnrollment() {
        SessionTokenController.shared.fetchSessionTokenWithCompletionHandler {
            
            
            guard let sessionData = SessionTokenController.shared.sessionTokenData else {
                print("failed to get session token")
                return
            }
            
            let configuration = CPSdkConfiguration(withFdCustomerId: fdCustomerId, encryptionKey: sessionData.security.publicKey, accessToken: sessionData.security.tokenID, configId: UseCases.manualEnrollment.rawValue, andPostUrl: callBackEndpoint)
            
            let manualConfiguration = ManualEnrollmentConfiguration()
            manualConfiguration.firstName = "Fred"
            manualConfiguration.lastName = "Rogers"
            
            guard let manualEnrollment = self.sdk.manualEnrollment(withCpSdkConfiguration: configuration, andManualEnrollmentConfiguration: manualConfiguration) else {
                print("failed to create manual enrollment object")
                return
            }
            
            DispatchQueue.main.async {
                manualEnrollment.start(completionHandler: { (params) in
                    print("finished manual enrollment")
                })
            }
            
        }
    }
    
    
    
    private func accountValidation() {
        SessionTokenController.shared.fetchSessionTokenWithCompletionHandler {
        
            
            guard let sessionData = SessionTokenController.shared.sessionTokenData else {
                print("failed to get session token")
                return
            }
        
            let configuration = CPSdkConfiguration(withFdCustomerId: fdCustomerId, encryptionKey: sessionData.security.publicKey, accessToken: sessionData.security.tokenID, configId: UseCases.microDepositWithAccountInput.rawValue, andPostUrl: callBackEndpoint)
            
            let accountValidationConfiguration = AccountValidationConfiguration()
            
            
            guard let accountValidation = self.sdk.accountValidation(withCpSdkConfiguration: configuration, andAccountValidationConfiguration: accountValidationConfiguration) else {
                print("failed to create account validation object")
                return
            }
            
            DispatchQueue.main.async {
                accountValidation.start(completionHandler: { (params) in
                    print("finished")
                })
            }
            
        }
    }
    
}// end class
